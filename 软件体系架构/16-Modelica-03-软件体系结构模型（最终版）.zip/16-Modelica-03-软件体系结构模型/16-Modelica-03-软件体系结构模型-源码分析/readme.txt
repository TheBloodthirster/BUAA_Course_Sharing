All files in this directory ("Modelica") and in all subdirectories,
especially all files that build package "Modelica" and the contents
of the directory "Modelica/Resources" are licensed by the
Modelica Association under the 3-Clause BSD License.
Copyright © 1998-2020, Modelica Association and contributors

These files are free software and the use is completely at your own risk;
they can be redistributed and/or modified under the terms of the
BSD 3-Clause license. For license conditions (including the disclaimer of warranty) visit:
https://modelica.org/licenses/modelica-3-clause-bsd.

Licensor:
Modelica Association
(Ideella Föreningar 822003-8858 in Linköping)
c/o PELAB, IDA, Linköpings Universitet
S-58183 Linköping
Sweden
email: Board@Modelica.org
web  : https://www.Modelica.org
