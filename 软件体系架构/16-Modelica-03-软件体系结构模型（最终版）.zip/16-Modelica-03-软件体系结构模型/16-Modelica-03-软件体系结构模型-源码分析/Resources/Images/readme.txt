This directory contains png-pictures which are referenced in the
documentation of the Modelica package.
